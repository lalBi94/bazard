#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "_libPrototype.h"

//FIXERK

void fonctionPourK(){
    printf("Valeur de K ? : ");
    fflush(stdin);
    scanf("%d", &K);
}