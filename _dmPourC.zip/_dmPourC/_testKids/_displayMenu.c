#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "_libPrototype.h"

void displayMenu(){
    printf("\nChoissez un numero ci-dessous :\n");
    printf("\t--> 1. Entrer N\n");//
    printf("\t--> 2. Entrer K\n");//
    printf("\t--> 3. Entrer le prenom des enfants\n");//
    printf("\t--> 4. Afficher le prenom des enfants\n");//
    printf("\t--> 5. Rendre la liste circulaire\n");
    printf("\t--> 6. Lancer le jeu\n");
    printf("\t--> 7. Quitter le jeu\n\n");
}