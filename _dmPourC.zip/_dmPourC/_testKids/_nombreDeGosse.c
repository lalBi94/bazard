#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "_libPrototype.h"

void nombreEnfant(){
    printf("Combien d'enfant ? : ");
    fflush(stdin);
    scanf("%d", &N);
}