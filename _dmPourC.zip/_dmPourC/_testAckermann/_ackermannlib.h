#ifndef __ACKERMANN__
#define __ACKERMANN__

int main();
int ackermann(int m, int n);

#endif 